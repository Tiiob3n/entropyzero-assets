tellraw @a [{"text":"[VIGIE] ","color":"dark_aqua","bold":true},{"text":"Debris sweep in 1 minute.","color":"gray","bold":false}]
schedule function darktimer:darktimerwarn10s 50s
