tellraw @a [{"text":"[VIGIE] ","color":"dark_aqua","bold":true},{"text":"Debris sweep in 10 minutes. Pick up what you dropped.","color":"gray","bold":false}]
schedule function darktimer:darktimerwarn1 540s
