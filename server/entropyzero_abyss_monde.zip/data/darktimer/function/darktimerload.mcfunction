schedule function darktimer:darktimerwarn10 30s
