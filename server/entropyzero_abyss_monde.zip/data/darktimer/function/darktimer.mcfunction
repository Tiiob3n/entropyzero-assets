kill @e[type=item]
tellraw @a [{"text":"[VIGIE] ","color":"dark_aqua","bold":true},{"text":"Sweep done. Loose items returned to the entropy.","color":"aqua","bold":false}]
schedule function darktimer:darktimerload 1s
