tellraw @a [{"text":"[VIGIE] ","color":"dark_aqua","bold":true},{"text":"Debris sweep in 10 seconds!","color":"gold","bold":false}]
schedule function darktimer:darktimer 10s
