fill ~-3 ~ ~-3 ~3 ~4 ~3 minecraft:air
fill ~-3 ~-1 ~-3 ~3 ~-1 ~3 packforge:briques_reveil
setblock ~3 ~-1 ~ minecraft:water
setblock ~-2 ~5 ~-2 packforge:lampe_reveil
setblock ~2 ~5 ~2 packforge:lampe_reveil
setblock ~-2 ~3 ~-2 minecraft:light[level=15]
setblock ~2 ~3 ~2 minecraft:light[level=15]
setblock ~-2 ~3 ~2 minecraft:light[level=12]
setblock ~2 ~3 ~-2 minecraft:light[level=12]
forceload remove ~ ~
tag @s remove ez_pending
