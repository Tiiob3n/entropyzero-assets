fill -3 198 -3 3 202 3 minecraft:air
fill -3 197 -3 3 197 3 packforge:briques_reveil
setblock 3 197 0 minecraft:water
setblock -2 203 -2 packforge:lampe_reveil
setblock 2 203 2 packforge:lampe_reveil
setblock -2 201 -2 minecraft:light[level=15]
setblock 2 201 2 minecraft:light[level=15]
setblock -2 201 2 minecraft:light[level=12]
setblock 2 201 -2 minecraft:light[level=12]
scoreboard players set #pocket ez_init 1
