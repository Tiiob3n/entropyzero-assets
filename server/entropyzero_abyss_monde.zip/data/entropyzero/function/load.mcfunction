scoreboard objectives add ez_init dummy
gamerule doDaylightCycle false
gamerule doWeatherCycle false
gamerule doInsomnia false
gamerule doPatrolSpawning false
gamerule doTraderSpawning false
gamerule spawnRadius 0
forceload add 0 0
setworldspawn 0 198 0
