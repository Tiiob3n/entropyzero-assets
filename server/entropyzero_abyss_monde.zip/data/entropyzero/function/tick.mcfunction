execute unless score #pocket ez_init matches 1 if loaded 0 198 0 run function entropyzero:pocket
execute unless score #n ez_init matches 1.. if entity @a[tag=ez_awake] run scoreboard players set #n ez_init 1
execute if score #pocket ez_init matches 1 as @a[tag=!ez_awake] run function entropyzero:wake
execute as @a[tag=ez_pending] at @s if loaded ~ ~ ~ run function entropyzero:pocket_here
