$forceload add $(x) $(z)
$tp @s $(x) 198 $(z)
$spawnpoint @s $(x) 198 $(z)
effect give @s minecraft:resistance 15 255 true
effect give @s minecraft:water_breathing 15 0 true
tag @s add ez_pending
