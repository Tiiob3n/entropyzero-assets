scoreboard players add #n ez_init 1
execute if score #n ez_init matches 1 run data modify storage entropyzero:p pos set value {x:0,z:0}
execute if score #n ez_init matches 2 run data modify storage entropyzero:p pos set value {x:1000,z:0}
execute if score #n ez_init matches 3 run data modify storage entropyzero:p pos set value {x:0,z:1000}
execute if score #n ez_init matches 4 run data modify storage entropyzero:p pos set value {x:-1000,z:0}
execute if score #n ez_init matches 5 run data modify storage entropyzero:p pos set value {x:0,z:-1000}
execute if score #n ez_init matches 6 run data modify storage entropyzero:p pos set value {x:1000,z:1000}
execute if score #n ez_init matches 7 run data modify storage entropyzero:p pos set value {x:-1000,z:1000}
execute if score #n ez_init matches 8 run data modify storage entropyzero:p pos set value {x:-1000,z:-1000}
execute if score #n ez_init matches 9 run data modify storage entropyzero:p pos set value {x:1000,z:-1000}
execute if score #n ez_init matches 10 run data modify storage entropyzero:p pos set value {x:2000,z:0}
execute if score #n ez_init matches 11 run data modify storage entropyzero:p pos set value {x:0,z:2000}
execute if score #n ez_init matches 12 run data modify storage entropyzero:p pos set value {x:-2000,z:0}
execute if score #n ez_init matches 13 run data modify storage entropyzero:p pos set value {x:0,z:-2000}
execute if score #n ez_init matches 14 run data modify storage entropyzero:p pos set value {x:2000,z:1000}
execute if score #n ez_init matches 15 run data modify storage entropyzero:p pos set value {x:1000,z:2000}
execute if score #n ez_init matches 16 run data modify storage entropyzero:p pos set value {x:-1000,z:2000}
execute if score #n ez_init matches 17 run data modify storage entropyzero:p pos set value {x:-2000,z:1000}
execute if score #n ez_init matches 18 run data modify storage entropyzero:p pos set value {x:-2000,z:-1000}
execute if score #n ez_init matches 19 run data modify storage entropyzero:p pos set value {x:-1000,z:-2000}
execute if score #n ez_init matches 20 run data modify storage entropyzero:p pos set value {x:1000,z:-2000}
execute if score #n ez_init matches 21 run data modify storage entropyzero:p pos set value {x:2000,z:-1000}
execute if score #n ez_init matches 22 run data modify storage entropyzero:p pos set value {x:2000,z:2000}
execute if score #n ez_init matches 23 run data modify storage entropyzero:p pos set value {x:-2000,z:2000}
execute if score #n ez_init matches 24 run data modify storage entropyzero:p pos set value {x:-2000,z:-2000}
execute if score #n ez_init matches 25 run data modify storage entropyzero:p pos set value {x:2000,z:-2000}
execute if score #n ez_init matches 26.. run data modify storage entropyzero:p pos set value {x:0,z:4000}
execute if score #n ez_init matches 26.. store result storage entropyzero:p pos.x int 1000 run scoreboard players get #n ez_init
function entropyzero:goto with storage entropyzero:p pos
give @s packforge:stone_hammer
give @s botanypots:terracotta_botany_pot
give @s minecraft:dirt 2
give @s minecraft:oak_sapling 2
give @s minecraft:bread 8
give @s minecraft:torch 4
give @s packforge:cellule_de_stase
give @s ftbquests:book
tellraw @s [{"text":"VIGIE : Cycle de stase interrompu. Caisson n° ","color":"aqua","italic":true},{"score":{"name":"#n","objective":"ez_init"},"color":"aqua","italic":true},{"text":" ouvert. Bonjour. Je suis désolée.","color":"aqua","italic":true}]
tellraw @s [{"text":"VIGIE: Stasis cycle interrupted. Pod no. ","color":"aqua","italic":true},{"score":{"name":"#n","objective":"ez_init"},"color":"aqua","italic":true},{"text":" open. Hello. I am sorry.","color":"aqua","italic":true}]
setblock 0 -250 0 packforge:point_zero
tag @s add ez_awake
