tellraw @a {"text":"VIGIE : J'ai coupé l'alimentation de ton caisson moi-même. Il fallait que quelqu'un descende. Pardon.","color":"aqua","italic":true}
tellraw @a {"text":"VIGIE: I cut the power to your pod myself. Someone had to go down. I am sorry.","color":"aqua","italic":true}
title @a title {"text":"Entropy: zero","color":"gold"}
title @a subtitle {"text":"Entropie : zéro","color":"yellow"}
playsound minecraft:ui.toast.challenge_complete master @a
fill -1 224 -1 1 254 1 minecraft:air
fill -1 223 -1 1 223 1 packforge:terre_de_genese
setblock 0 224 0 minecraft:oak_sapling
tellraw @a {"text":"VIGIE : Entropie : zéro. Nouvelle genèse en cours. Merci de m'avoir crue. / Entropy: zero. New genesis under way. Thank you for believing me.","color":"aqua"}
